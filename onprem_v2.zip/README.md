# Synapxe RHEL8 Audit Package - On-Premises V2

## Overview
This package contains enhanced scripts and configurations for auditing RHEL8 systems in on-premises environments.

## Features
- Modern HTML reporting with interactive elements
- Improved error handling and robustness
- Comprehensive CIS compliance checks
- Enhanced system auditing capabilities
- Real-time progress tracking

## Usage
Run the main audit script:
```bash
./onprem_v2/synapxe_rhel8_audit.sh
```

## Requirements
- RHEL 8.x
- Root access
- Basic system utilities (bash, grep, awk, etc.)
