# Synapxe RHEL8 Audit Package

This package contains scripts and configurations for auditing RHEL8 systems according to Synapxe security standards.

## Features
- Enhanced HTML reporting
- Improved error handling
- CIS compliance checks
- Comprehensive system auditing
